import { Text, SafeAreaView, StyleSheet, View, TouchableOpacity} from 'react-native';
import { useState } from 'react';

export default function App() {

  const [normal, setNormal] = useState(1);
  const [prioritario, setPrioritario] = useState(1);
  const [altaPrioridade, setAltaPrioridade] = useState(1);
  const [senhaAtual, setSenhaAtual] = useState('');

function GerarSenha(prioridade){
  let senha = '';

  if (prioridade === 'normal') {
      senha = `N0${normal.toString()}`;
      setNormal(normal + 1);
    } else if (prioridade === 'prioritario') {
      senha = `P0${prioritario.toString()}`;
      setPrioritario(prioritario + 1);
    } else if (prioridade === 'alta') {
      senha = `AP0${altaPrioridade.toString().padStart(2, '0')}`;
      setAltaPrioridade(altaPrioridade + 1);
    }

    setSenhaAtual(senha);
}
 return (
    <SafeAreaView style={styles.container}>
    <View style={styles.caixaSenha}>
      <Text style={styles.senhaTitulo}> Gerar Senha </Text>
       <Text style={styles.senhaTexto}>{senhaAtual}</Text>
    </View>
      <View style={styles.caixaBotao}>
        <TouchableOpacity style={styles.botao} onPress={() => GerarSenha('normal')}>
          <Text style={styles.text}>Normal</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botao} onPress={() => GerarSenha('prioridade')}>
          <Text style={styles.text}>Prioridade</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botao} onPress={() => GerarSenha('alta')}>
          <Text style={styles.text}>Alta Prioridade</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#96C6EB',
    gap: 30,
    padding: 8,
  },
  caixaBotao:{
    justifyContent: 'center',
    alignItems: 'center',
    gap: 40,
  },
  botao: {
    backgroundColor: 'azure',
    width: 200,
    height: 80,
    borderRadius: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
     fontSize: 15,
     color: "black"
  },
  caixaSenha:{
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  senhaTitulo:{
    fontSize: 20,
    fontWeight: 700,
  },
  senhaTexto: {
    fontSize: 15,
  }
});
